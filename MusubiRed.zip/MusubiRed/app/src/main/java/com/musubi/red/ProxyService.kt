package com.musubi.red

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

class ProxyService : Service() {
    private var proxy: ProxyServer? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("m", "Musubi Red", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "m").setContentTitle("Musubi Red")
            .setContentText("Proxy activo en el puerto 8080").setSmallIcon(android.R.drawable.ic_menu_share).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (proxy == null) {
            try { proxy = ProxyServer(8080).also { it.start() } } catch (e: Exception) { stopSelf() }
        }
        return START_STICKY
    }

    override fun onDestroy() { proxy?.stop(); proxy = null; super.onDestroy() }
}
