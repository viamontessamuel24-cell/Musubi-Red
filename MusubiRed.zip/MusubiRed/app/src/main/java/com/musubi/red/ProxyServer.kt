package com.musubi.red

import java.io.InputStream
import java.io.OutputStream
import java.net.*
import java.util.concurrent.Executors

/** Proxy HTTP/HTTPS (CONNECT). Sus conexiones salen desde este móvil, así que usan la VPN activa. */
class ProxyServer(private val port: Int) {
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var running = false

    fun start() {
        server = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress("0.0.0.0", port)) }
        running = true
        pool.execute {
            while (running) {
                try { val c = server!!.accept(); pool.execute { handle(c) } } catch (e: Exception) { if (!running) break }
            }
        }
    }

    fun stop() { running = false; try { server?.close() } catch (_: Exception) {}; pool.shutdownNow() }

    private fun readHead(i: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 16384) {
            val b = i.read(); if (b < 0) return null
            sb.append(b.toChar())
            if (sb.endsWith("\r\n\r\n")) return sb.toString()
        }
        return null
    }

    private fun handle(c: Socket) {
        var r: Socket? = null
        try {
            c.soTimeout = 30000
            val head = readHead(c.getInputStream()) ?: return c.close()
            c.soTimeout = 0
            val parts = head.substringBefore("\r\n").split(" ")
            if (parts.size < 3) return c.close()
            r = Socket()
            if (parts[0].equals("CONNECT", true)) {
                val host = parts[1].substringBeforeLast(":")
                val p = parts[1].substringAfterLast(":").toIntOrNull() ?: 443
                r.connect(InetSocketAddress(host, p), 15000)
                c.getOutputStream().apply { write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray()); flush() }
            } else {
                val u = URL(parts[1])
                r.connect(InetSocketAddress(u.host, if (u.port > 0) u.port else 80), 15000)
                val lines = head.trimEnd().split("\r\n")
                    .filter { !it.startsWith("Proxy-Connection", true) && !it.startsWith("Connection", true) }.toMutableList()
                lines[0] = "${parts[0]} ${u.file.ifEmpty { "/" }} ${parts[2]}"
                r.getOutputStream().apply { write((lines.joinToString("\r\n") + "\r\nConnection: close\r\n\r\n").toByteArray()); flush() }
            }
            val a = c; val b = r
            val t = Thread { copy(a.getInputStream(), b.getOutputStream(), a, b) }
            t.start()
            copy(b.getInputStream(), a.getOutputStream(), a, b)
        } catch (e: Exception) {
            try { c.close() } catch (_: Exception) {}
            try { r?.close() } catch (_: Exception) {}
        }
    }

    private fun copy(i: InputStream, o: OutputStream, a: Socket, b: Socket) {
        try { val buf = ByteArray(16384); while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); o.flush() } } catch (_: Exception) {}
        try { a.close() } catch (_: Exception) {}
        try { b.close() } catch (_: Exception) {}
    }
}
