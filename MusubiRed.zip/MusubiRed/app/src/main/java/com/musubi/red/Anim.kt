package com.musubi.red

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View
import android.view.animation.PathInterpolator
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation

fun spring(v: View, p: DynamicAnimation.ViewProperty, to: Float, damping: Float = 0.5f, stiff: Float = 380f): SpringAnimation {
    val a = SpringAnimation(v, p, to)
    a.spring.setDampingRatio(damping).setStiffness(stiff)
    return a
}

/** Efecto iOS: al tocar se encoge con resorte y rebota al soltar. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressable(to: Float = 0.92f) {
    val sx = spring(this, DynamicAnimation.SCALE_X, 1f)
    val sy = spring(this, DynamicAnimation.SCALE_Y, 1f)
    setOnTouchListener { _, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx.animateToFinalPosition(to); sy.animateToFinalPosition(to) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { sx.animateToFinalPosition(1f); sy.animateToFinalPosition(1f) }
        }
        false
    }
}

fun View.enter(delay: Long, dy: Float) {
    alpha = 0f; translationY = dy
    animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(750)
        .setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f)).start()
}

fun TextView.swap(t: String) {
    if (text.toString() == t) return
    animate().alpha(0f).setDuration(120).withEndAction {
        text = t
        animate().alpha(1f).setDuration(240).start()
    }.start()
}

fun View.pop() {
    scaleX = 1.45f; scaleY = 1.45f
    val sx = spring(this, DynamicAnimation.SCALE_X, 1f, 0.35f, 300f)
    val sy = spring(this, DynamicAnimation.SCALE_Y, 1f, 0.35f, 300f)
    sx.setStartValue(1.45f); sy.setStartValue(1.45f)
    sx.start(); sy.start()
}
