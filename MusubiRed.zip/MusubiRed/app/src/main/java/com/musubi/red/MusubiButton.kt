package com.musubi.red

import android.animation.*
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator

class MusubiButton(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {
    var active = false
        set(v) { field = v; if (v) pulse.start() else { pulse.cancel(); invalidate() } }

    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3 * d }
    private val wave = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.12f
    }
    private var pulseT = 0f
    private var tapT = -1f

    private val pulse = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { pulseT = it.animatedValue as Float; invalidate() }
    }
    private val tap = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 750
        addUpdateListener { tapT = it.animatedValue as Float; invalidate() }
        addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { tapT = -1f; invalidate() } })
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = minOf(width, height) / 2f * 0.6f

        if (active) for (i in 0..2) {
            val t = (pulseT + i / 3f) % 1f
            wave.color = Color.argb(((1 - t) * 150).toInt(), 57, 255, 136)
            c.drawCircle(cx, cy, r + t * r * 0.55f, wave)
        }
        if (tapT >= 0f) {
            wave.color = Color.argb(((1 - tapT) * 220).toInt(), 200, 160, 255)
            c.drawCircle(cx, cy, r + tapT * r * 0.8f, wave)
            c.drawCircle(cx, cy, r + tapT * r * 0.45f, wave)
        }
        glow.shader = RadialGradient(cx, cy, r * 1.4f,
            if (active) 0x6639FF88 else 0x66A855F7, 0x00000000, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.4f, glow)

        fill.shader = RadialGradient(cx - r * .3f, cy - r * .4f, r * 1.4f,
            intArrayOf(0xEEB57BFF.toInt(), 0xEE6A2BD9.toInt(), 0xEE1A0840.toInt()), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, fill)

        // brillo de cristal
        glow.shader = LinearGradient(0f, cy - r, 0f, cy, 0x77FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawOval(RectF(cx - r * .78f, cy - r * .95f, cx + r * .78f, cy - r * .1f), glow)

        line.color = if (active) 0xFF39FF88.toInt() else 0x99FFFFFF.toInt()
        c.drawCircle(cx, cy, r, line)
        txt.textSize = r * 0.3f
        c.drawText("Musubi", cx, cy + txt.textSize / 3f, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { tap.start(); return true }
            MotionEvent.ACTION_UP -> performClick()
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
