package com.musubi.red

import android.animation.*
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import androidx.dynamicanimation.animation.DynamicAnimation

class MusubiButton(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {
    var active = false
        set(v) {
            field = v
            ValueAnimator.ofFloat(act, if (v) 1f else 0f).apply {
                duration = 800; interpolator = OvershootInterpolator(1.2f)
                addUpdateListener { act = it.animatedValue as Float }
            }.start()
        }

    private val d = resources.displayMetrics.density
    private val ev = ArgbEvaluator()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val st = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.1f
        setShadowLayer(10f, 0f, 4f, 0x66200A55)
    }
    private var act = 0f
    private var clock = 0f
    private var tapT = -1f
    private val sx = spring(this, DynamicAnimation.SCALE_X, 1f)
    private val sy = spring(this, DynamicAnimation.SCALE_Y, 1f)

    private val clockAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2800; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { clock = it.animatedValue as Float; invalidate() }
    }
    private val tapAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 900
        addUpdateListener { tapT = it.animatedValue as Float }
        addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { tapT = -1f } })
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); clockAnim.start() }
    override fun onDetachedFromWindow() { clockAnim.cancel(); super.onDetachedFromWindow() }

    private fun h(v: Long) = v.toInt()
    private fun mix(a: Int, b: Int, t: Float) = ev.evaluate(t.coerceIn(0f, 1f), a, b) as Int
    private fun al(c: Int, a: Float) = (c and 0x00FFFFFF) or (a.coerceIn(0f, 255f).toInt() shl 24)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = minOf(width, height) / 2f * 0.44f
        val big = r * 1.34f
        val a = act.coerceIn(0f, 1f)
        val br = 1f + 0.014f * Math.sin(clock * 2 * Math.PI).toFloat()
        c.save(); c.scale(br, br, cx, cy)

        // resplandor
        p.shader = RadialGradient(cx, cy, big * 1.65f, mix(0x55A855F7, 0x6639FF88, a), 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, big * 1.65f, p)

        // ondas (activo)
        st.strokeWidth = 2 * d
        if (a > 0.02f) for (i in 0..2) {
            val t = (clock + i / 3f) % 1f
            st.color = al(if (i == 1) 0x39FF88 else 0xA855F7, (1 - t) * 130f * a)
            c.drawCircle(cx, cy, big + t * big * 0.5f, st)
        }
        // onda al tocar
        if (tapT >= 0f) {
            st.strokeWidth = 3 * d
            st.color = al(0xC9B3FF, (1 - tapT) * 220f)
            c.drawCircle(cx, cy, big + tapT * big * 0.5f, st)
            val t2 = maxOf(0f, tapT - 0.18f)
            st.color = al(0xFFFFFF, (1 - t2) * 160f)
            c.drawCircle(cx, cy, big + t2 * big * 0.5f, st)
        }

        // anillo de cristal
        p.shader = RadialGradient(cx, cy, big, intArrayOf(0x00FFFFFF, 0x2DC9B3FF, h(0x99FFFFFF)),
            floatArrayOf(0.55f, 0.82f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, big, p)
        st.strokeWidth = 2 * d; st.color = mix(h(0xCCFFFFFF), h(0xCC39FF88), a * 0.8f)
        c.drawCircle(cx, cy, big, st)
        st.strokeWidth = 1 * d; st.color = 0x55B49CFF
        c.drawCircle(cx, cy, big * 0.86f, st)
        val ar = RectF(cx - big * 0.94f, cy - big * 0.94f, cx + big * 0.94f, cy + big * 0.94f)
        st.strokeWidth = 4 * d; st.color = h(0xE6FFFFFF)
        c.drawArc(ar, 200f, 70f, false, st)
        st.color = 0x66FFFFFF; c.drawArc(ar, 20f, 40f, false, st)

        // esfera
        p.shader = RadialGradient(cx - r * .35f, cy - r * .45f, r * 1.6f,
            intArrayOf(h(0xFFA77BFF), h(0xFF6A2FE0), h(0xFF2C0E78)), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
        st.strokeWidth = 2.5f * d; st.color = mix(0x66FFFFFF, h(0xFF39FF88), a)
        c.drawCircle(cx, cy, r, st)
        p.shader = LinearGradient(0f, cy - r * .92f, 0f, cy - r * .15f, h(0x88FFFFFF), 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawOval(RectF(cx - r * .7f, cy - r * .92f, cx + r * .7f, cy - r * .15f), p)
        p.shader = LinearGradient(0f, cy + r * .55f, 0f, cy + r * .9f, 0x00FFFFFF, 0x33FFFFFF, Shader.TileMode.CLAMP)
        c.drawOval(RectF(cx - r * .45f, cy + r * .55f, cx + r * .45f, cy + r * .9f), p)
        p.shader = null

        txt.textSize = r * 0.34f
        c.drawText("Musubi", cx, cy + txt.textSize / 3f, txt)
        c.restore()
    }

    private fun release() { sx.animateToFinalPosition(1f); sy.animateToFinalPosition(1f) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx.animateToFinalPosition(0.93f); sy.animateToFinalPosition(0.93f); tapAnim.start() }
            MotionEvent.ACTION_UP -> { release(); performClick() }
            MotionEvent.ACTION_CANCEL -> release()
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
