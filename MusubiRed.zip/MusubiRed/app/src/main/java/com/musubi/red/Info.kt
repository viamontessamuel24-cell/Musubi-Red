package com.musubi.red

/** Edita aquí tu información de "Acerca de" y "Donar". */
object Info {
    const val VERSION = "Versión 1.2"
    const val ABOUT = "Musubi Red comparte la conexión de la VPN de tu Android con tu iPhone. Tú enciendes la VPN en el Android, tocas Musubi y el iPhone navega y descarga a través de ella, sin instalar nada en el iPhone."
    const val STEPS = "1 · Enciende tu VPN en el Android.\n2 · Abre Musubi Red y toca el botón Musubi.\n3 · Toca «Crear Wi-Fi» (o activa la zona Wi-Fi del sistema).\n4 · En el iPhone, conéctate a ese Wi-Fi con la clave que muestra la app.\n5 · En el iPhone: Ajustes > Wi-Fi > (i) > Configurar proxy > Manual.\n6 · Servidor = la IP que muestra la app · Puerto = 8080 · Guardar.\n7 · Listo: el iPhone usa la VPN de tu Android."
    /** Pega aquí el enlace del video tutorial cuando lo tengas. Vacío = "próximamente". */
    const val TUTORIAL_URL = ""

    const val NAME = "Samuel Viamontes Escobar"
    const val ROLE = "Creador de contenido · Desarrollador web y de apps iOS\nMarketing digital · Negocios de streaming\nCreador de TransferPay (Transfermóvil para iOS)"
    const val EMAIL = "samuelviamontes07@gmail.com"
    val LINKS = listOf(
        "YouTube" to "https://youtube.com/@bytebytecu?si=OV-1jI1OGRhsx3qk",
        "Instagram" to "https://www.instagram.com/byteabytecu?igsh=MTN2Z280d21meGRpdg==",
        "Facebook" to "https://www.facebook.com/share/17s1Y4jyar/",
        "Página web" to "https://bytebyteweb.wordpress.com/",
        "Correo" to "mailto:$EMAIL"
    )

    const val DONATE_TEXT = "Musubi Red es gratis. Si te sirvió y quieres apoyar el proyecto, puedes donar (solo para Cuba):"
    const val CARD = "9205 1299 7420 0942"
    const val CONFIRM = "52985279"
}
