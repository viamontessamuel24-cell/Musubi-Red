package com.musubi.red

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.*
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {
    private lateinit var btn: MusubiButton
    private lateinit var status: TextView
    private lateinit var info: TextView
    private var on = false
    private var res: WifiManager.LocalOnlyHotspotReservation? = null
    private var wifi = ""
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        btn = findViewById(R.id.btn); status = findViewById(R.id.status); info = findViewById(R.id.info)
        btn.setOnClickListener { toggle() }
        findViewById<TextView>(R.id.chipHotspot).setOnClickListener { startHotspot() }
        findViewById<TextView>(R.id.chipSettings).setOnClickListener { openTether() }
        refresh()
    }

    private fun perms(): Boolean {
        val need = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) { need += Manifest.permission.POST_NOTIFICATIONS; need += Manifest.permission.NEARBY_WIFI_DEVICES }
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isNotEmpty()) { requestPermissions(miss.toTypedArray(), 1); return false }
        return true
    }

    private fun toggle() {
        if (!perms()) return
        on = !on
        if (on) startForegroundService(Intent(this, ProxyService::class.java))
        else { stopService(Intent(this, ProxyService::class.java)); res?.close(); res = null; wifi = "" }
        btn.active = on
        refresh()
    }

    private fun startHotspot() {
        if (!perms()) return
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    res = r
                    wifi = if (Build.VERSION.SDK_INT >= 30)
                        r.softApConfiguration.let { "Wi-Fi: ${it.ssid}\nClave: ${it.passphrase}\n\n" }
                    else @Suppress("DEPRECATION") r.wifiConfiguration.let { "Wi-Fi: ${it?.SSID}\nClave: ${it?.preSharedKey}\n\n" }
                    ui.postDelayed({ refresh() }, 800)
                }
                override fun onFailed(reason: Int) {
                    Toast.makeText(this@MainActivity, "No se pudo crear. Usa la zona Wi-Fi del sistema.", Toast.LENGTH_LONG).show()
                }
            }, ui)
        } catch (e: Exception) { Toast.makeText(this, "Activa Wi-Fi y ubicación", Toast.LENGTH_LONG).show() }
    }

    private fun openTether() {
        try { startActivity(Intent("android.settings.TETHER_SETTINGS")) }
        catch (e: Exception) { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
    }

    private fun ips(): String = try {
        NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback && !it.name.startsWith("tun") }
            .flatMap { ni -> ni.inetAddresses.toList().filterIsInstance<Inet4Address>().map { "${it.hostAddress}  (${ni.name})" } }
            .joinToString("\n")
    } catch (e: Exception) { "" }

    private fun refresh() {
        status.text = if (on) "Compartiendo · puerto 8080" else "Toca para compartir"
        info.text = if (!on) "1) Enciende tu VPN\n2) Toca Musubi\n3) Crea el Wi-Fi o activa tu zona Wi-Fi"
        else wifi + "Proxy (usa la IP del Wi-Fi compartido):\n" + ips() +
            "\n\niPhone: Ajustes > Wi-Fi > (i) > Configurar proxy > Manual\nServidor = esa IP · Puerto = 8080"
    }

    override fun onDestroy() { super.onDestroy() }
}
