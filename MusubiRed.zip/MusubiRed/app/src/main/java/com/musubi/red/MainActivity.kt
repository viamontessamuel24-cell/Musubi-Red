package com.musubi.red

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {
    private lateinit var btn: MusubiButton
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var sheet: View
    private lateinit var scrim: View
    private lateinit var sheetAnim: SpringAnimation
    private var sheetOpen = false
    private var on = false
    private var res: WifiManager.LocalOnlyHotspotReservation? = null
    private var wifi = ""
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(id: Int) = findViewById<TextView>(id)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        btn = findViewById(R.id.btn); status = tv(R.id.status); info = tv(R.id.info)
        sheet = findViewById(R.id.sheet); scrim = findViewById(R.id.scrim)
        if (Build.VERSION.SDK_INT >= 28) findViewById<View>(R.id.panel).outlineSpotShadowColor = 0x668B5CF6
        fillAbout()

        val chipH = tv(R.id.chipHotspot); val chipS = tv(R.id.chipSettings)
        val bi = tv(R.id.btnInfo); val bh = tv(R.id.btnHeart); val close = tv(R.id.aClose)
        for (v in listOf(chipH, chipS, bi, bh, close)) v.pressable()
        btn.setOnClickListener { toggle() }
        chipH.setOnClickListener { startHotspot() }
        chipS.setOnClickListener { openTether() }
        bi.setOnClickListener { openSheet(false) }
        bh.setOnClickListener { it.pop(); openSheet(true) }
        close.setOnClickListener { closeSheet() }
        scrim.setOnClickListener { closeSheet() }
        setupSheet()
        refresh(false)

        listOf<View>(findViewById(R.id.topRow), btn, status, info, findViewById(R.id.chips))
            .forEachIndexed { i, v -> v.enter(90L * i, dp(40).toFloat()) }
    }

    // ---------- Acerca de / Donar ----------
    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; setTextColor(0xFF1F7A4D.toInt()); textSize = 14f; gravity = Gravity.CENTER
        setPadding(dp(10), dp(14), dp(10), dp(14)); setBackgroundResource(R.drawable.chip)
        setOnClickListener { onClick() }; pressable()
    }

    private fun fillRows(box: LinearLayout, chips: List<TextView>) {
        chips.chunked(2).forEach { row ->
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEachIndexed { i, c ->
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(if (i == 1) dp(6) else 0, 0, if (row.size == 2 && i == 0) dp(6) else 0, 0)
                l.addView(c, lp)
            }
            val lp2 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp2.topMargin = dp(10)
            box.addView(l, lp2)
        }
    }

    private fun open(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (e: Exception) { Toast.makeText(this, "No se pudo abrir", Toast.LENGTH_SHORT).show() }
    }

    private fun copy(label: String, text: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
    }

    private fun fillAbout() {
        tv(R.id.aVersion).text = Info.VERSION; tv(R.id.aAbout).text = Info.ABOUT; tv(R.id.aSteps).text = Info.STEPS
        tv(R.id.aName).text = Info.NAME; tv(R.id.aRole).text = Info.ROLE
        val t = tv(R.id.chipTutorial)
        if (Info.TUTORIAL_URL.isNotEmpty()) { t.text = "▶ Ver video tutorial"; t.setOnClickListener { open(Info.TUTORIAL_URL) }; t.pressable() }
        else t.text = "▶ Video tutorial: próximamente"
        fillRows(findViewById(R.id.linksBox), Info.LINKS.map { (l, u) -> chip(l) { open(u) } })

        tv(R.id.dText).text = Info.DONATE_TEXT
        tv(R.id.dCard).text = "Tarjeta\n${Info.CARD}\n\nNúmero a confirmar\n${Info.CONFIRM}"
        fillRows(findViewById(R.id.dChips), listOf(
            chip("Copiar tarjeta") { copy("Tarjeta", Info.CARD.replace(" ", "")) },
            chip("Copiar número") { copy("Número", Info.CONFIRM) },
            chip("Escribir al correo") { open("mailto:" + Info.EMAIL) }
        ))
    }

    // ---------- Panel inferior con resorte ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun setupSheet() {
        sheetAnim = spring(sheet, DynamicAnimation.TRANSLATION_Y, 0f, 0.85f, 260f)
        sheetAnim.addEndListener { _, _, _, _ -> if (!sheetOpen) { sheet.visibility = View.INVISIBLE; scrim.visibility = View.GONE } }
        var y0 = 0f
        findViewById<View>(R.id.sheetHeader).setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sheetAnim.cancel(); y0 = e.rawY - sheet.translationY }
                MotionEvent.ACTION_MOVE -> sheet.translationY = maxOf(0f, e.rawY - y0)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    if (sheet.translationY > sheet.height * 0.3f) closeSheet() else sheetAnim.animateToFinalPosition(0f)
            }
            true
        }
    }

    private fun openSheet(donate: Boolean) {
        findViewById<View>(R.id.infoBox).visibility = if (donate) View.GONE else View.VISIBLE
        findViewById<View>(R.id.donateBox).visibility = if (donate) View.VISIBLE else View.GONE
        findViewById<View>(R.id.sheetScroll).scrollTo(0, 0)
        val h = (resources.displayMetrics.heightPixels * (if (donate) 0.68f else 0.88f)).toInt()
        sheetOpen = true
        sheetAnim.cancel()
        sheet.layoutParams.height = h
        sheet.requestLayout()
        sheet.translationY = h.toFloat()
        sheet.visibility = View.VISIBLE
        scrim.visibility = View.VISIBLE; scrim.animate().alpha(1f).setDuration(300).start()
        sheetAnim.animateToFinalPosition(0f)
    }

    private fun closeSheet() {
        sheetOpen = false
        scrim.animate().alpha(0f).setDuration(250).start()
        sheetAnim.animateToFinalPosition(sheet.height.toFloat())
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (sheetOpen) closeSheet() else super.onBackPressed() }

    // ---------- Proxy / Wi-Fi (sin cambios) ----------
    private fun perms(): Boolean {
        val need = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) { need += Manifest.permission.POST_NOTIFICATIONS; need += Manifest.permission.NEARBY_WIFI_DEVICES }
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isNotEmpty()) { requestPermissions(miss.toTypedArray(), 1); return false }
        return true
    }

    private fun toggle() {
        if (!perms()) return
        on = !on
        if (on) startForegroundService(Intent(this, ProxyService::class.java))
        else { stopService(Intent(this, ProxyService::class.java)); res?.close(); res = null; wifi = "" }
        btn.active = on
        refresh(true)
    }

    private fun startHotspot() {
        if (!perms()) return
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    res = r
                    wifi = if (Build.VERSION.SDK_INT >= 30)
                        r.softApConfiguration.let { "Wi-Fi: ${it.ssid}\nClave: ${it.passphrase}\n\n" }
                    else @Suppress("DEPRECATION") r.wifiConfiguration.let { "Wi-Fi: ${it?.SSID}\nClave: ${it?.preSharedKey}\n\n" }
                    ui.postDelayed({ refresh(true) }, 800)
                }
                override fun onFailed(reason: Int) {
                    Toast.makeText(this@MainActivity, "No se pudo crear. Usa la zona Wi-Fi del sistema.", Toast.LENGTH_LONG).show()
                }
            }, ui)
        } catch (e: Exception) { Toast.makeText(this, "Activa Wi-Fi y ubicación", Toast.LENGTH_LONG).show() }
    }

    private fun openTether() {
        try { startActivity(Intent("android.settings.TETHER_SETTINGS")) }
        catch (e: Exception) { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
    }

    private fun ips(): String = try {
        NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback && !it.name.startsWith("tun") }
            .flatMap { ni -> ni.inetAddresses.toList().filterIsInstance<Inet4Address>().map { "${it.hostAddress}  (${ni.name})" } }
            .joinToString("\n")
    } catch (e: Exception) { "" }

    private fun refresh(animate: Boolean) {
        val st = if (on) "Compartiendo · puerto 8080" else "Toca para compartir"
        val tx = if (!on) "1) Enciende tu VPN\n2) Toca Musubi\n3) Crea el Wi-Fi o activa tu zona Wi-Fi"
        else wifi + "Proxy (usa la IP del Wi-Fi compartido):\n" + ips() +
            "\n\niPhone: Ajustes > Wi-Fi > (i) > Configurar proxy > Manual\nServidor = esa IP · Puerto = 8080"
        if (animate) { status.swap(st); info.swap(tx) } else { status.text = st; info.text = tx }
    }
}
