plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.musubi.red"
    compileSdk = 34
    defaultConfig { applicationId = "com.musubi.red"; minSdk = 26; targetSdk = 34; versionCode = 3; versionName = "1.2" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.dynamicanimation:dynamicanimation:1.0.0") }
